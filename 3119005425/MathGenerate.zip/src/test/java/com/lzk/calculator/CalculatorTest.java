package com.lzk.calculator;

import com.lzk.utils.IOUtils;
import org.junit.Test;

import java.io.IOException;

public class CalculatorTest {
    @Test
    public void testGenerate() throws IOException {
        Calculator calculator = new Calculator();
//        calculator.generate(1000,"C:\\Users\\22154\\Desktop\\题.txt","C:\\Users\\22154\\Desktop\\答案.txt");
//        calculator.check("C:\\Users\\22154\\Desktop\\题.txt","C:\\Users\\22154\\Desktop\\答案.txt","C:\\Users\\22154\\Desktop\\报告.txt");
    }
}

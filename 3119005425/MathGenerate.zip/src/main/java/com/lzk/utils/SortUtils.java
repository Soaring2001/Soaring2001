package com.lzk.utils;

import java.util.ArrayList;

public class SortUtils {
    public static void insertSort(ArrayList list) {
        for (int index = 0;index < list.size();index++){

        }
    }
}

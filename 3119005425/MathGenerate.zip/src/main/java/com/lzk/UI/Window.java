package com.lzk.UI;

import com.lzk.calculator.Calculator;
import com.lzk.utils.MathUtils;

import javax.swing.*;
import javax.swing.filechooser.FileSystemView;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;

public class Window {
    private int num = 100;
    private String topPath = new String("C:\\");
    private String ansPath = new String("C:\\");
    private JFrame f = new JFrame("四则运算生成器");
    private JPanel windowTop = new JPanel(new BorderLayout());
    private JPanel numPanel = new JPanel();
    private JPanel rangePanel = new JPanel();
    private JPanel windowCenter = new JPanel();
    private JPanel topPathPanel = new JPanel();
    private JPanel ansPathPanel = new JPanel();
    private JPanel windowBottom = new JPanel(new BorderLayout());
    private JTextArea ta = new JTextArea("请输入要生成的题目数量（默认为100）");
    private JTextField tf = new JTextField(10);
    private JTextArea taRange = new JTextArea("请输入要生成的题目数值最大值（默认为10）");
    private JTextField tfRange = new JTextField(10);
    private JRadioButton r1 = new JRadioButton("生成题目", true);
    private JRadioButton r2 = new JRadioButton("检测题目", false);
    private JTextArea topicPathArea = new JTextArea(1, 30);
    private JButton topicButton = new JButton("选择题目文件目录");
    private JTextArea answerPathArea = new JTextArea(1, 30);
    private JButton answerButton = new JButton("选择答案文件目录");
    private JButton run = new JButton("运行");
    JFileChooser jf = new JFileChooser();
    ButtonGroup bg = new ButtonGroup();

    public void init() {
        ta.setEditable(false);
        topicPathArea.setEditable(false);
        answerPathArea.setEditable(false);
        tf.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    num = Integer.valueOf(tf.getText());
                } catch (Exception exp) {
                    tf.setText("请输入正整数");
                }

            }
        });
        tfRange.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    MathUtils.setNumRange(Integer.valueOf(tfRange.getText()));
                } catch (Exception exp) {
                    tfRange.setText("请输入正整数");
                }
            }
        });
        numPanel.add(ta);
        numPanel.add(tf);
        rangePanel.add(taRange);
        rangePanel.add(tfRange);
        windowTop.add(numPanel, BorderLayout.NORTH);
        windowTop.add(rangePanel, BorderLayout.CENTER);
        bg.add(r1);
        bg.add(r2);
        windowCenter.add(r1);
        windowCenter.add(r2);
        topPathPanel.add(topicPathArea);
        topPathPanel.add(topicButton);
        topicButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                topicPathArea.setText("");
                FileSystemView fsv = FileSystemView.getFileSystemView();
                jf.setCurrentDirectory(fsv.getHomeDirectory());
                if (r1.isSelected()) {
                    jf.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
                    jf.setDialogTitle("请选择题目文件的存储路径");
                    jf.showDialog(topicButton, "确定");
                } else if (r2.isSelected()) {
                    jf.setFileSelectionMode(JFileChooser.FILES_ONLY);
                    jf.setDialogTitle("请选择题目文件的存储路径");
                    jf.showDialog(topicButton, "确定");
                }
                topicPathArea.append(jf.getSelectedFile().getPath());
                topPath = jf.getSelectedFile().getPath();
            }
        });
        ansPathPanel.add(answerPathArea);
        ansPathPanel.add(answerButton);
        answerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                answerPathArea.setText("");
                FileSystemView fsv = FileSystemView.getFileSystemView();
                jf.setCurrentDirectory(fsv.getHomeDirectory());
                if (r1.isSelected()) {
                    jf.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
                    jf.setDialogTitle("请选择题目文件的存储路径");
                    jf.showDialog(answerButton, "确定");
                } else if (r2.isSelected()) {
                    jf.setFileSelectionMode(JFileChooser.FILES_ONLY);
                    jf.setDialogTitle("请选择题目文件的存储路径");
                    jf.showDialog(answerButton, "确定");
                }

                answerPathArea.append(jf.getSelectedFile().getPath());
                ansPath = jf.getSelectedFile().getPath();
            }
        });
        windowBottom.add(topPathPanel, BorderLayout.NORTH);
        windowBottom.add(ansPathPanel, BorderLayout.CENTER);
        windowBottom.add(run, BorderLayout.SOUTH);
        run.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (r1.isSelected()) {
                    try {
                        new Calculator().generate(num,
                                topPath + "\\" + "Exercises.txt",
                                ansPath + "\\" + "Answers.txt");
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                } else if (r2.isSelected()) {
                    try {
                        new Calculator().check(topPath, ansPath, ansPath);
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        });
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.add(windowTop, BorderLayout.NORTH);
        f.add(windowCenter, BorderLayout.CENTER);
        f.add(windowBottom, BorderLayout.SOUTH);
        f.pack();
        f.setVisible(true);
    }
}

package com.lzk.main;

import com.lzk.UI.Window;
import com.lzk.calculator.Calculator;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        new Window().init();
    }
}

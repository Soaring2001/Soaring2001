package com.lyw;

import junit.framework.TestCase;
import org.junit.jupiter.api.Test;

public class TxtTest extends TestCase {

    @Test
    public void testReadTxt() {
        // 路径存在，正常读取
        String str = Txt.readTxt("D:\\大学\\大三\\大三上\\软件工程\\测试文本\\orig.txt");
        String[] strings = str.split(" ");
        for (String string : strings) {
            System.out.println(string);
        }
    }

    @Test
    public void testWriteTxt() {
        // 路径存在，正常写入
        double[] elem = {0.11, 0.22, 0.33, 0.44, 0.55};
        for (int i = 0; i < elem.length; i++) {
            Txt.writeTxt(elem[i], "D:\\大学\\大三\\大三上\\软件工程\\测试文本\\result.txt");
        }
    }

    @Test
    public void testReadTxtFail() {
        // 路径不存在，读取失败
        String str = Txt.readTxt("D:\\大学\\大三\\大三上\\软件工程\\测试文本\\orig.txtnone.txt");
    }

    @Test
    public void testWriteTxtFail() {
        // 路径错误，写入失败
        double[] elem = {0.11, 0.22, 0.33, 0.44, 0.55};
        for (int i = 0; i < elem.length; i++) {
            Txt.writeTxt(elem[i], "User:\\大学\\大三\\大三上\\软件工程\\测试文本\\result.txt");
        }
    }
}
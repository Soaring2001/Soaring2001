package com.lyw;

import junit.framework.TestCase;
import org.junit.Test;

public class MainPaperCompareTest extends TestCase {

    @Test
    public void testOrigAndAll(){
        String[] str = new String[6];
        str[0] = Txt.readTxt("D:\\大学\\大三\\大三上\\软件工程\\测试文本\\orig.txt");
        str[1] = Txt.readTxt("D:\\大学\\大三\\大三上\\软件工程\\测试文本\\orig_0.8_add.txt");
        str[2] = Txt.readTxt("D:\\大学\\大三\\大三上\\软件工程\\测试文本\\orig_0.8_del.txt");
        str[3] = Txt.readTxt("D:\\大学\\大三\\大三上\\软件工程\\测试文本\\orig_0.8_dis_1.txt");
        str[4] = Txt.readTxt("D:\\大学\\大三\\大三上\\软件工程\\测试文本\\orig_0.8_dis_10.txt");
        str[5] = Txt.readTxt("D:\\大学\\大三\\大三上\\软件工程\\测试文本\\orig_0.8_dis_15.txt");
        String ansFileName = "D:\\大学\\大三\\大三上\\软件工程\\测试文本\\result.txt";
        for(int i = 0; i <= 5; i++){
            double ans = Hamming.getSimilarity(SimHash.getSimHash(str[0]), SimHash.getSimHash(str[i]));
            Txt.writeTxt(ans, ansFileName);
        }
    }

    @Test
    public void testOrigAndOrig(){
        String str0 = Txt.readTxt("D:\\大学\\大三\\大三上\\软件工程\\测试文本\\orig.txt");
        String str1 = Txt.readTxt("D:\\大学\\大三\\大三上\\软件工程\\测试文本\\orig.txt");
        String ansFileName = "D:\\大学\\大三\\大三上\\软件工程\\测试文本\\resultOrigAndOrigTest.txt";
        double ans = Hamming.getSimilarity(SimHash.getSimHash(str0), SimHash.getSimHash(str1));
        Txt.writeTxt(ans, ansFileName);
    }

    @Test
    public void testOrigAndAdd(){
        String str0 = Txt.readTxt("D:\\大学\\大三\\大三上\\软件工程\\测试文本\\orig.txt");
        String str1 = Txt.readTxt("D:\\大学\\大三\\大三上\\软件工程\\测试文本\\orig_0.8_add.txt");
        String ansFileName = "D:\\大学\\大三\\大三上\\软件工程\\测试文本\\resultOrigAndAddTest.txt";
        double ans = Hamming.getSimilarity(SimHash.getSimHash(str0), SimHash.getSimHash(str1));
        Txt.writeTxt(ans, ansFileName);
    }

    @Test
    public void testOrigAndDel(){
        String str0 = Txt.readTxt("D:\\大学\\大三\\大三上\\软件工程\\测试文本\\orig.txt");
        String str1 = Txt.readTxt("D:\\大学\\大三\\大三上\\软件工程\\测试文本\\orig_0.8_del.txt");
        String ansFileName = "D:\\大学\\大三\\大三上\\软件工程\\测试文本\\resultOrigAndDelTest.txt";
        double ans = Hamming.getSimilarity(SimHash.getSimHash(str0), SimHash.getSimHash(str1));
        Txt.writeTxt(ans, ansFileName);
    }

    @Test
    public void testOrigAndDis1(){
        String str0 = Txt.readTxt("D:\\大学\\大三\\大三上\\软件工程\\测试文本\\orig.txt");
        String str1 = Txt.readTxt("D:\\大学\\大三\\大三上\\软件工程\\测试文本\\orig_0.8_dis_1.txt");
        String ansFileName = "D:\\大学\\大三\\大三上\\软件工程\\测试文本\\resultOrigAndDis1Test.txt";
        double ans = Hamming.getSimilarity(SimHash.getSimHash(str0), SimHash.getSimHash(str1));
        Txt.writeTxt(ans, ansFileName);
    }

    @Test
    public void testOrigAndDis10(){
        String str0 = Txt.readTxt("D:\\大学\\大三\\大三上\\软件工程\\测试文本\\orig.txt");
        String str1 = Txt.readTxt("D:\\大学\\大三\\大三上\\软件工程\\测试文本\\orig_0.8_dis_10.txt");
        String ansFileName = "D:\\大学\\大三\\大三上\\软件工程\\测试文本\\resultOrigAndDis10Test.txt";
        double ans = Hamming.getSimilarity(SimHash.getSimHash(str0), SimHash.getSimHash(str1));
        Txt.writeTxt(ans, ansFileName);
    }

    @Test
    public void testOrigAndDis15(){
        String str0 = Txt.readTxt("D:\\大学\\大三\\大三上\\软件工程\\测试文本\\orig.txt");
        String str1 = Txt.readTxt("D:\\大学\\大三\\大三上\\软件工程\\测试文本\\orig_0.8_dis_15.txt");
        String ansFileName = "D:\\大学\\大三\\大三上\\软件工程\\测试文本\\resultOrigAndDis15Test.txt";
        double ans = Hamming.getSimilarity(SimHash.getSimHash(str0), SimHash.getSimHash(str1));
        Txt.writeTxt(ans,ansFileName);
    }
}
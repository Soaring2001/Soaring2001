package com.lyw;

import junit.framework.TestCase;
import org.junit.Test;

public class HammingTest extends TestCase {
    @Test
    public void testGetHammingDistance() {
        String str0 = Txt.readTxt("D:\\大学\\大三\\大三上\\软件工程\\测试文本\\orig.txt");
        String str1 = Txt.readTxt("D:\\大学\\大三\\大三上\\软件工程\\测试文本\\orig_0.8_add.txt");
        int distance = Hamming.getHammingDistance(SimHash.getSimHash(str0), SimHash.getSimHash(str1));
        System.out.println("海明距离：" + distance);
        System.out.println("相似度: " + (100 - distance * 100 / 128) + "%");
    }

    public void testGetSimilarity() {
        String str0 = Txt.readTxt("D:\\大学\\大三\\大三上\\软件工程\\测试文本\\orig.txt");
        String str1 = Txt.readTxt("D:\\大学\\大三\\大三上\\软件工程\\测试文本\\orig_0.8_add.txt");
        int distance = Hamming.getHammingDistance(SimHash.getSimHash(str0), SimHash.getSimHash(str1));
        double similarity = Hamming.getSimilarity(SimHash.getSimHash(str0), SimHash.getSimHash(str1));
        System.out.println("str0和str1的汉明距离: " + distance);
        System.out.println("str0和str1的相似度:" + similarity);
    }
}
package com.lyw;

import junit.framework.TestCase;
import org.junit.jupiter.api.Test;

public class SimHashTest extends TestCase {

    @Test
    public void testGetHash(){
        String[] strings = {"余华", "是", "一位", "真正", "的", "作家"};
        for (String string : strings) {
            String stringHash = SimHash.getHash(string);
            System.out.println(stringHash.length());
            System.out.println(stringHash);
        }
    }

    @Test
    public void testGetSimHash(){
        String str0 = Txt.readTxt("D:\\大学\\大三\\大三上\\软件工程\\测试文本\\orig.txt");
        String str1 = Txt.readTxt("D:\\大学\\大三\\大三上\\软件工程\\测试文本\\orig_0.8_add.txt");
        System.out.println(SimHash.getSimHash(str0));
        System.out.println(SimHash.getSimHash(str1));
    }
}
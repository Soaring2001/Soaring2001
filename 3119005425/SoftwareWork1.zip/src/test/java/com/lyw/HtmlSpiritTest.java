package com.lyw;

import junit.framework.TestCase;
import org.junit.Test;

public class HtmlSpiritTest extends TestCase {
    @Test
    public void testDelHTMLTag() {
        String str0 = "aaaaa<scrip>bbbbb<aaaaa>";
        String str1 = "aaaaabbbbb";
        System.out.println( HtmlSpirit.delHTMLTag(str0));
        System.out.println( HtmlSpirit.delHTMLTag(str1));

    }
}
package com.lyw;

import junit.framework.TestCase;
import org.junit.jupiter.api.Test;

public class ShortStringExceptionTest extends TestCase {

    @Test
    public void testShortStringException(){
        //测试str.length()<200的情况
        System.out.println(SimHash.getSimHash("一位正真的作家"));
    }
}
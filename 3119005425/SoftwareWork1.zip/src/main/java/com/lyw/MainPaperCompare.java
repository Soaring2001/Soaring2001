package com.lyw;

import java.util.Scanner;

public class MainPaperCompare {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.print("请输入论文原文位置：");
        String str0 = sc.next();
        System.out.print("请输入抄袭论文位置：");
        String str1 = sc.next();
        System.out.print("请输入答案文件的位置：");
        String str2 = sc.next();

        // 由字符串得出对应的 simHash值
        String simHash0 = SimHash.getSimHash(Txt.readTxt(str0));
        String simHash1 = SimHash.getSimHash(Txt.readTxt(str1));
        // 由 simHash值求出相似度
        double similarity = Hamming.getSimilarity(simHash0, simHash1);
        System.out.println(similarity);
        // 把相似度写入最后的结果文件中
        Txt.writeTxt(similarity, str2);
        // 退出程序
        System.exit(0);
    }

}
